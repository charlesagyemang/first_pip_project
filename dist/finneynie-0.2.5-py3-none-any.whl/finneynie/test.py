def test(name):
    return name
